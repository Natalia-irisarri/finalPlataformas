﻿namespace tpAgencia_Gpo_2
{
    partial class FormUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            mostrar_usuario = new Button();
            Volver_desde_usuario = new Button();
            label_usuarios = new Label();
            label_id = new Label();
            label_nombre = new Label();
            label_apellido = new Label();
            label_dni = new Label();
            label_email = new Label();
            textBox_id = new TextBox();
            textBox_nombre = new TextBox();
            textBox_apellido = new TextBox();
            textBox_dni = new TextBox();
            textBox_email = new TextBox();
            button_Agregar = new Button();
            button_Modificar = new Button();
            button_Eliminar = new Button();
            dataGridView_usuarios = new DataGridView();
            id = new DataGridViewTextBoxColumn();
            nombre = new DataGridViewTextBoxColumn();
            apellido = new DataGridViewTextBoxColumn();
            dni = new DataGridViewTextBoxColumn();
            credito = new DataGridViewTextBoxColumn();
            email = new DataGridViewTextBoxColumn();
            admin = new DataGridViewTextBoxColumn();
            bloqueado = new DataGridViewTextBoxColumn();
            resHotel = new DataGridViewTextBoxColumn();
            resVuelo = new DataGridViewTextBoxColumn();
            bienvenida = new Label();
            Bienvenida_usuario = new Label();
            btn_modificarCredito = new Button();
            btn_buscarUsuario = new Button();
            textBox_buscarUsuario = new TextBox();
            btn_agregarCredito = new Button();
            label_Credito = new Label();
            textBox_credito = new TextBox();
            checkBox_admin = new CheckBox();
            checkBox_bloqueado = new CheckBox();
            textBox_pass = new TextBox();
            label_pass = new Label();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView_usuarios).BeginInit();
            SuspendLayout();
            // 
            // mostrar_usuario
            // 
            mostrar_usuario.Location = new Point(35, 121);
            mostrar_usuario.Margin = new Padding(2);
            mostrar_usuario.Name = "mostrar_usuario";
            mostrar_usuario.Size = new Size(181, 32);
            mostrar_usuario.TabIndex = 6;
            mostrar_usuario.Text = "Mostrar / Actualizar Usuarios";
            mostrar_usuario.UseVisualStyleBackColor = true;
            mostrar_usuario.Click += mostrar_usuario_Click;
            // 
            // Volver_desde_usuario
            // 
            Volver_desde_usuario.BackColor = Color.FromArgb(192, 255, 255);
            Volver_desde_usuario.Location = new Point(35, 405);
            Volver_desde_usuario.Name = "Volver_desde_usuario";
            Volver_desde_usuario.Size = new Size(75, 23);
            Volver_desde_usuario.TabIndex = 8;
            Volver_desde_usuario.Text = "Volver";
            Volver_desde_usuario.UseVisualStyleBackColor = false;
            Volver_desde_usuario.Click += Volver_desde_usuario_Click;
            // 
            // label_usuarios
            // 
            label_usuarios.AutoSize = true;
            label_usuarios.Font = new Font("Segoe UI", 19F, FontStyle.Bold, GraphicsUnit.Point);
            label_usuarios.Location = new Point(680, 33);
            label_usuarios.Name = "label_usuarios";
            label_usuarios.Size = new Size(119, 36);
            label_usuarios.TabIndex = 9;
            label_usuarios.Text = "Usuarios";
            // 
            // label_id
            // 
            label_id.AutoSize = true;
            label_id.Location = new Point(1011, 84);
            label_id.Name = "label_id";
            label_id.Size = new Size(17, 15);
            label_id.TabIndex = 11;
            label_id.Text = "id";
            // 
            // label_nombre
            // 
            label_nombre.AutoSize = true;
            label_nombre.Location = new Point(977, 121);
            label_nombre.Name = "label_nombre";
            label_nombre.Size = new Size(51, 15);
            label_nombre.TabIndex = 12;
            label_nombre.Text = "Nombre";
            // 
            // label_apellido
            // 
            label_apellido.AutoSize = true;
            label_apellido.Location = new Point(977, 156);
            label_apellido.Name = "label_apellido";
            label_apellido.Size = new Size(51, 15);
            label_apellido.TabIndex = 13;
            label_apellido.Text = "Apellido";
            // 
            // label_dni
            // 
            label_dni.AutoSize = true;
            label_dni.Location = new Point(1003, 192);
            label_dni.Name = "label_dni";
            label_dni.Size = new Size(25, 15);
            label_dni.TabIndex = 14;
            label_dni.Text = "Dni";
            // 
            // label_email
            // 
            label_email.AutoSize = true;
            label_email.Location = new Point(992, 228);
            label_email.Name = "label_email";
            label_email.Size = new Size(36, 15);
            label_email.TabIndex = 15;
            label_email.Text = "Email";
            // 
            // textBox_id
            // 
            textBox_id.Enabled = false;
            textBox_id.Location = new Point(1044, 76);
            textBox_id.Name = "textBox_id";
            textBox_id.ReadOnly = true;
            textBox_id.Size = new Size(269, 23);
            textBox_id.TabIndex = 20;
            // 
            // textBox_nombre
            // 
            textBox_nombre.Location = new Point(1044, 113);
            textBox_nombre.Name = "textBox_nombre";
            textBox_nombre.Size = new Size(269, 23);
            textBox_nombre.TabIndex = 21;
            // 
            // textBox_apellido
            // 
            textBox_apellido.Location = new Point(1044, 148);
            textBox_apellido.Name = "textBox_apellido";
            textBox_apellido.Size = new Size(269, 23);
            textBox_apellido.TabIndex = 22;
            // 
            // textBox_dni
            // 
            textBox_dni.Location = new Point(1044, 184);
            textBox_dni.Name = "textBox_dni";
            textBox_dni.Size = new Size(269, 23);
            textBox_dni.TabIndex = 23;
            // 
            // textBox_email
            // 
            textBox_email.Location = new Point(1044, 220);
            textBox_email.Name = "textBox_email";
            textBox_email.Size = new Size(269, 23);
            textBox_email.TabIndex = 24;
            // 
            // button_Agregar
            // 
            button_Agregar.BackColor = Color.LightGreen;
            button_Agregar.Location = new Point(992, 364);
            button_Agregar.Name = "button_Agregar";
            button_Agregar.Size = new Size(75, 23);
            button_Agregar.TabIndex = 28;
            button_Agregar.Text = "Agregar";
            button_Agregar.UseVisualStyleBackColor = false;
            button_Agregar.Click += button_Agregar_Click;
            // 
            // button_Modificar
            // 
            button_Modificar.BackColor = Color.FromArgb(255, 255, 192);
            button_Modificar.Location = new Point(1119, 364);
            button_Modificar.Name = "button_Modificar";
            button_Modificar.Size = new Size(75, 23);
            button_Modificar.TabIndex = 29;
            button_Modificar.Text = "Modificar";
            button_Modificar.UseVisualStyleBackColor = false;
            button_Modificar.Click += button_Modificar_Click;
            // 
            // button_Eliminar
            // 
            button_Eliminar.BackColor = Color.LightCoral;
            button_Eliminar.Location = new Point(1238, 364);
            button_Eliminar.Name = "button_Eliminar";
            button_Eliminar.Size = new Size(75, 23);
            button_Eliminar.TabIndex = 30;
            button_Eliminar.Text = "Eliminar";
            button_Eliminar.UseVisualStyleBackColor = false;
            button_Eliminar.Click += button_Eliminar_Click;
            // 
            // dataGridView_usuarios
            // 
            dataGridView_usuarios.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView_usuarios.Columns.AddRange(new DataGridViewColumn[] { id, nombre, apellido, dni, credito, email, admin, bloqueado, resHotel, resVuelo });
            dataGridView_usuarios.Location = new Point(35, 250);
            dataGridView_usuarios.Name = "dataGridView_usuarios";
            dataGridView_usuarios.RowTemplate.Height = 25;
            dataGridView_usuarios.Size = new Size(893, 178);
            dataGridView_usuarios.TabIndex = 32;
            dataGridView_usuarios.CellContentClick += dataGridView_usuarios_CellContentClick;
            dataGridView_usuarios.CellDoubleClick += dataGridView_usuarios_CellContentClick;
            // 
            // id
            // 
            id.HeaderText = "ID de usuario";
            id.Name = "id";
            id.ReadOnly = true;
            id.Width = 110;
            // 
            // nombre
            // 
            nombre.HeaderText = "Nombre";
            nombre.Name = "nombre";
            nombre.ReadOnly = true;
            // 
            // apellido
            // 
            apellido.HeaderText = "Apellido";
            apellido.Name = "apellido";
            apellido.ReadOnly = true;
            // 
            // dni
            // 
            dni.HeaderText = "Dni";
            dni.Name = "dni";
            dni.ReadOnly = true;
            // 
            // credito
            // 
            credito.HeaderText = "Credito";
            credito.Name = "credito";
            credito.ReadOnly = true;
            // 
            // email
            // 
            email.HeaderText = "Email";
            email.Name = "email";
            email.ReadOnly = true;
            // 
            // admin
            // 
            admin.HeaderText = "Es Admin?";
            admin.Name = "admin";
            admin.ReadOnly = true;
            // 
            // bloqueado
            // 
            bloqueado.HeaderText = "Esta Bloqueado?";
            bloqueado.Name = "bloqueado";
            bloqueado.ReadOnly = true;
            // 
            // resHotel
            // 
            resHotel.HeaderText = "Reserva de Hotel";
            resHotel.Name = "resHotel";
            resHotel.ReadOnly = true;
            resHotel.Visible = false;
            resHotel.Width = 120;
            // 
            // resVuelo
            // 
            resVuelo.HeaderText = "Reserva de Vuelo";
            resVuelo.Name = "resVuelo";
            resVuelo.ReadOnly = true;
            resVuelo.Visible = false;
            resVuelo.Width = 120;
            // 
            // bienvenida
            // 
            bienvenida.AutoSize = true;
            bienvenida.Font = new Font("Segoe UI", 19F, FontStyle.Bold, GraphicsUnit.Point);
            bienvenida.Location = new Point(24, 33);
            bienvenida.Name = "bienvenida";
            bienvenida.Size = new Size(166, 36);
            bienvenida.TabIndex = 33;
            bienvenida.Text = "Bienvenido: ";
            // 
            // Bienvenida_usuario
            // 
            Bienvenida_usuario.AutoSize = true;
            Bienvenida_usuario.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            Bienvenida_usuario.Location = new Point(206, 41);
            Bienvenida_usuario.Name = "Bienvenida_usuario";
            Bienvenida_usuario.Size = new Size(0, 25);
            Bienvenida_usuario.TabIndex = 34;
            // 
            // btn_modificarCredito
            // 
            btn_modificarCredito.BackColor = Color.FromArgb(255, 255, 192);
            btn_modificarCredito.Location = new Point(734, 180);
            btn_modificarCredito.Name = "btn_modificarCredito";
            btn_modificarCredito.Size = new Size(75, 23);
            btn_modificarCredito.TabIndex = 40;
            btn_modificarCredito.Text = "Modificar";
            btn_modificarCredito.UseVisualStyleBackColor = false;
            btn_modificarCredito.Click += btn_modificarCredito_Click_1;
            // 
            // btn_buscarUsuario
            // 
            btn_buscarUsuario.Location = new Point(35, 169);
            btn_buscarUsuario.Margin = new Padding(2);
            btn_buscarUsuario.Name = "btn_buscarUsuario";
            btn_buscarUsuario.Size = new Size(181, 32);
            btn_buscarUsuario.TabIndex = 41;
            btn_buscarUsuario.Text = "Buscar Usuarios";
            btn_buscarUsuario.UseVisualStyleBackColor = true;
            btn_buscarUsuario.Click += btn_buscarUsuario_Click;
            // 
            // textBox_buscarUsuario
            // 
            textBox_buscarUsuario.Location = new Point(233, 178);
            textBox_buscarUsuario.Name = "textBox_buscarUsuario";
            textBox_buscarUsuario.PlaceholderText = "ingrese dni para buscar";
            textBox_buscarUsuario.Size = new Size(155, 23);
            textBox_buscarUsuario.TabIndex = 42;
            // 
            // btn_agregarCredito
            // 
            btn_agregarCredito.BackColor = Color.LightGreen;
            btn_agregarCredito.Location = new Point(734, 136);
            btn_agregarCredito.Name = "btn_agregarCredito";
            btn_agregarCredito.Size = new Size(75, 23);
            btn_agregarCredito.TabIndex = 39;
            btn_agregarCredito.Text = "Agregar";
            btn_agregarCredito.UseVisualStyleBackColor = false;
            btn_agregarCredito.Click += btn_agregarCredito_Click;
            // 
            // label_Credito
            // 
            label_Credito.AutoSize = true;
            label_Credito.Location = new Point(572, 144);
            label_Credito.Name = "label_Credito";
            label_Credito.Size = new Size(46, 15);
            label_Credito.TabIndex = 38;
            label_Credito.Text = "Credito";
            // 
            // textBox_credito
            // 
            textBox_credito.Location = new Point(572, 175);
            textBox_credito.Name = "textBox_credito";
            textBox_credito.Size = new Size(114, 23);
            textBox_credito.TabIndex = 37;
            // 
            // checkBox_admin
            // 
            checkBox_admin.AutoSize = true;
            checkBox_admin.Location = new Point(1044, 299);
            checkBox_admin.Name = "checkBox_admin";
            checkBox_admin.Size = new Size(76, 19);
            checkBox_admin.TabIndex = 43;
            checkBox_admin.Text = "Es Admin";
            checkBox_admin.UseVisualStyleBackColor = true;
            // 
            // checkBox_bloqueado
            // 
            checkBox_bloqueado.AutoSize = true;
            checkBox_bloqueado.Location = new Point(1044, 324);
            checkBox_bloqueado.Name = "checkBox_bloqueado";
            checkBox_bloqueado.Size = new Size(83, 19);
            checkBox_bloqueado.TabIndex = 7;
            checkBox_bloqueado.Text = "Bloqueado";
            checkBox_bloqueado.UseVisualStyleBackColor = true;
            // 
            // textBox_pass
            // 
            textBox_pass.Location = new Point(1044, 263);
            textBox_pass.Name = "textBox_pass";
            textBox_pass.Size = new Size(269, 23);
            textBox_pass.TabIndex = 44;
            // 
            // label_pass
            // 
            label_pass.AutoSize = true;
            label_pass.Location = new Point(971, 271);
            label_pass.Name = "label_pass";
            label_pass.Size = new Size(57, 15);
            label_pass.TabIndex = 45;
            label_pass.Text = "Password";
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(192, 255, 255);
            button1.Location = new Point(35, 476);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 56;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // FormUsuario
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1385, 511);
            ControlBox = false;
            Controls.Add(button1);
            Controls.Add(label_pass);
            Controls.Add(textBox_pass);
            Controls.Add(checkBox_bloqueado);
            Controls.Add(checkBox_admin);
            Controls.Add(textBox_buscarUsuario);
            Controls.Add(btn_buscarUsuario);
            Controls.Add(btn_modificarCredito);
            Controls.Add(btn_agregarCredito);
            Controls.Add(label_Credito);
            Controls.Add(textBox_credito);
            Controls.Add(Bienvenida_usuario);
            Controls.Add(bienvenida);
            Controls.Add(dataGridView_usuarios);
            Controls.Add(button_Eliminar);
            Controls.Add(button_Modificar);
            Controls.Add(button_Agregar);
            Controls.Add(textBox_email);
            Controls.Add(textBox_dni);
            Controls.Add(textBox_apellido);
            Controls.Add(textBox_nombre);
            Controls.Add(textBox_id);
            Controls.Add(label_email);
            Controls.Add(label_dni);
            Controls.Add(label_apellido);
            Controls.Add(label_nombre);
            Controls.Add(label_id);
            Controls.Add(label_usuarios);
            Controls.Add(Volver_desde_usuario);
            Controls.Add(mostrar_usuario);
            Name = "FormUsuario";
            Text = "FormUsuario";
            Load += FormUsuario_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView_usuarios).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button mostrar_usuario;
        private DataGridView dataGridView_usuarios;
        private DataGridView dataGridView1;
        private Button Volver_desde_usuario;
        private Label label_usuarios;
        private Label Bienvenida_usuario;
        private Label label_id;
        private Label label_nombre;
        private Label label_apellido;
        private Label label_dni;
        private Label label_email;
        private Label label_reserva_hotel;
        private Label label_reserva_vuelo;
        private TextBox textBox_buscarUsuario;
        private TextBox textBox_id;
        private TextBox textBox_nombre;
        private TextBox textBox_apellido;
        private TextBox textBox_dni;
        private TextBox textBox_email;
        private TextBox textBox8;
        private TextBox textBox_resVuelo;
        private Button button_Agregar;
        private Button button_Modificar;
        private Button button_Eliminar;
        private TextBox textBox_resHotel;
        private DataGridView dataGridView2;
        private Label bienvenida;
        private Button btn_modificarCredito;
        private Button btn_buscarUsuario;
        private Button btn_agregarCredito;
        private Label label_Credito;
        private TextBox textBox_credito;
        private CheckBox checkBox_admin;
        private CheckBox checkBox_bloqueado;
        private DataGridViewTextBoxColumn id;
        private DataGridViewTextBoxColumn nombre;
        private DataGridViewTextBoxColumn apellido;
        private DataGridViewTextBoxColumn dni;
        private DataGridViewTextBoxColumn credito;
        private DataGridViewTextBoxColumn email;
        private DataGridViewTextBoxColumn admin;
        private DataGridViewTextBoxColumn bloqueado;
        private DataGridViewTextBoxColumn resHotel;
        private DataGridViewTextBoxColumn resVuelo;
        private TextBox textBox_pass;
        private Label label_pass;
        private Button button1;
    }
}