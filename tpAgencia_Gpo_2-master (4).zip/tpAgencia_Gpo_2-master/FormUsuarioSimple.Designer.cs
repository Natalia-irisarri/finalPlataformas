﻿namespace tpAgencia_Gpo_2
{
    partial class FormUsuarioSimple
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label_bienvenido_client = new Label();
            label_vista_usuario = new Label();
            textBox_email = new TextBox();
            textBox_dni = new TextBox();
            textBox_apellido = new TextBox();
            textBox_nombre = new TextBox();
            textBox_id = new TextBox();
            label_email = new Label();
            label_dni = new Label();
            label_apellido = new Label();
            label_nombre = new Label();
            label_id = new Label();
            button_Modificar = new Button();
            textBox_MiCredito = new TextBox();
            label_MICredito = new Label();
            button_agregar_credito = new Button();
            label_modificar_pasword = new Label();
            textBox_pass_viejo = new TextBox();
            textBox_pass_nuevo = new TextBox();
            button_modificar_password = new Button();
            label_datos_personales = new Label();
            label_ver_saldo_credito = new Label();
            label_set_usuario_actual = new Label();
            Volver_desde_usuario = new Button();
            SuspendLayout();
            // 
            // label_bienvenido_client
            // 
            label_bienvenido_client.AutoSize = true;
            label_bienvenido_client.Location = new Point(38, 51);
            label_bienvenido_client.Name = "label_bienvenido_client";
            label_bienvenido_client.Size = new Size(72, 15);
            label_bienvenido_client.TabIndex = 0;
            label_bienvenido_client.Text = "Bienvenido: ";
            // 
            // label_vista_usuario
            // 
            label_vista_usuario.AutoSize = true;
            label_vista_usuario.Location = new Point(507, 25);
            label_vista_usuario.Name = "label_vista_usuario";
            label_vista_usuario.Size = new Size(79, 15);
            label_vista_usuario.TabIndex = 1;
            label_vista_usuario.Text = "Panel Usuario";
            // 
            // textBox_email
            // 
            textBox_email.Location = new Point(880, 290);
            textBox_email.Name = "textBox_email";
            textBox_email.Size = new Size(269, 23);
            textBox_email.TabIndex = 43;
            // 
            // textBox_dni
            // 
            textBox_dni.Location = new Point(880, 254);
            textBox_dni.Name = "textBox_dni";
            textBox_dni.Size = new Size(269, 23);
            textBox_dni.TabIndex = 42;
            // 
            // textBox_apellido
            // 
            textBox_apellido.Location = new Point(880, 218);
            textBox_apellido.Name = "textBox_apellido";
            textBox_apellido.Size = new Size(269, 23);
            textBox_apellido.TabIndex = 41;
            // 
            // textBox_nombre
            // 
            textBox_nombre.Location = new Point(880, 183);
            textBox_nombre.Name = "textBox_nombre";
            textBox_nombre.Size = new Size(269, 23);
            textBox_nombre.TabIndex = 40;
            // 
            // textBox_id
            // 
            textBox_id.Enabled = false;
            textBox_id.Location = new Point(880, 146);
            textBox_id.Name = "textBox_id";
            textBox_id.ReadOnly = true;
            textBox_id.Size = new Size(269, 23);
            textBox_id.TabIndex = 39;
            // 
            // label_email
            // 
            label_email.AutoSize = true;
            label_email.Location = new Point(828, 298);
            label_email.Name = "label_email";
            label_email.Size = new Size(36, 15);
            label_email.TabIndex = 36;
            label_email.Text = "Email";
            // 
            // label_dni
            // 
            label_dni.AutoSize = true;
            label_dni.Location = new Point(839, 262);
            label_dni.Name = "label_dni";
            label_dni.Size = new Size(25, 15);
            label_dni.TabIndex = 35;
            label_dni.Text = "Dni";
            // 
            // label_apellido
            // 
            label_apellido.AutoSize = true;
            label_apellido.Location = new Point(813, 226);
            label_apellido.Name = "label_apellido";
            label_apellido.Size = new Size(51, 15);
            label_apellido.TabIndex = 34;
            label_apellido.Text = "Apellido";
            // 
            // label_nombre
            // 
            label_nombre.AutoSize = true;
            label_nombre.Location = new Point(813, 191);
            label_nombre.Name = "label_nombre";
            label_nombre.Size = new Size(51, 15);
            label_nombre.TabIndex = 33;
            label_nombre.Text = "Nombre";
            // 
            // label_id
            // 
            label_id.AutoSize = true;
            label_id.Location = new Point(847, 154);
            label_id.Name = "label_id";
            label_id.Size = new Size(17, 15);
            label_id.TabIndex = 32;
            label_id.Text = "id";
            // 
            // button_Modificar
            // 
            button_Modificar.BackColor = Color.FromArgb(255, 255, 192);
            button_Modificar.Location = new Point(979, 351);
            button_Modificar.Name = "button_Modificar";
            button_Modificar.Size = new Size(75, 23);
            button_Modificar.TabIndex = 46;
            button_Modificar.Text = "Modificar";
            button_Modificar.UseVisualStyleBackColor = false;
            button_Modificar.Click += button_Modificar_Click;
            // 
            // textBox_MiCredito
            // 
            textBox_MiCredito.Location = new Point(63, 233);
            textBox_MiCredito.Name = "textBox_MiCredito";
            textBox_MiCredito.Size = new Size(114, 23);
            textBox_MiCredito.TabIndex = 37;
            // 
            // label_MICredito
            // 
            label_MICredito.AutoSize = true;
            label_MICredito.Location = new Point(63, 202);
            label_MICredito.Name = "label_MICredito";
            label_MICredito.Size = new Size(69, 15);
            label_MICredito.TabIndex = 38;
            label_MICredito.Text = "Mi Credito: ";
            // 
            // button_agregar_credito
            // 
            button_agregar_credito.BackColor = Color.LightGreen;
            button_agregar_credito.Location = new Point(63, 282);
            button_agregar_credito.Name = "button_agregar_credito";
            button_agregar_credito.Size = new Size(114, 23);
            button_agregar_credito.TabIndex = 39;
            button_agregar_credito.Text = "Agregar Credito";
            button_agregar_credito.UseVisualStyleBackColor = false;
            button_agregar_credito.Click += button_agregar_credito_Click;
            // 
            // label_modificar_pasword
            // 
            label_modificar_pasword.AutoSize = true;
            label_modificar_pasword.Location = new Point(428, 202);
            label_modificar_pasword.Name = "label_modificar_pasword";
            label_modificar_pasword.Size = new Size(106, 15);
            label_modificar_pasword.TabIndex = 48;
            label_modificar_pasword.Text = "Modificar Pasword";
            // 
            // textBox_pass_viejo
            // 
            textBox_pass_viejo.Location = new Point(428, 233);
            textBox_pass_viejo.Name = "textBox_pass_viejo";
            textBox_pass_viejo.PlaceholderText = "Ingrese Contraseña anterior";
            textBox_pass_viejo.Size = new Size(219, 23);
            textBox_pass_viejo.TabIndex = 47;
            // 
            // textBox_pass_nuevo
            // 
            textBox_pass_nuevo.Location = new Point(428, 282);
            textBox_pass_nuevo.Name = "textBox_pass_nuevo";
            textBox_pass_nuevo.PlaceholderText = "Ingrese Su Nueva Contraseña";
            textBox_pass_nuevo.Size = new Size(219, 23);
            textBox_pass_nuevo.TabIndex = 50;
            // 
            // button_modificar_password
            // 
            button_modificar_password.BackColor = Color.FromArgb(255, 255, 192);
            button_modificar_password.Location = new Point(467, 338);
            button_modificar_password.Name = "button_modificar_password";
            button_modificar_password.Size = new Size(130, 23);
            button_modificar_password.TabIndex = 51;
            button_modificar_password.Text = "Modificar Pasword";
            button_modificar_password.UseVisualStyleBackColor = false;
            button_modificar_password.Click += button_modificar_password_Click;
            // 
            // label_datos_personales
            // 
            label_datos_personales.AutoSize = true;
            label_datos_personales.Location = new Point(958, 105);
            label_datos_personales.Name = "label_datos_personales";
            label_datos_personales.Size = new Size(96, 15);
            label_datos_personales.TabIndex = 52;
            label_datos_personales.Text = "Datos Personales";
            // 
            // label_ver_saldo_credito
            // 
            label_ver_saldo_credito.AutoSize = true;
            label_ver_saldo_credito.Location = new Point(153, 202);
            label_ver_saldo_credito.Name = "label_ver_saldo_credito";
            label_ver_saldo_credito.Size = new Size(0, 15);
            label_ver_saldo_credito.TabIndex = 53;
            // 
            // label_set_usuario_actual
            // 
            label_set_usuario_actual.AutoSize = true;
            label_set_usuario_actual.Location = new Point(129, 52);
            label_set_usuario_actual.Name = "label_set_usuario_actual";
            label_set_usuario_actual.Size = new Size(38, 15);
            label_set_usuario_actual.TabIndex = 54;
            label_set_usuario_actual.Text = "label1";
            // 
            // Volver_desde_usuario
            // 
            Volver_desde_usuario.BackColor = Color.FromArgb(192, 255, 255);
            Volver_desde_usuario.Location = new Point(38, 393);
            Volver_desde_usuario.Name = "Volver_desde_usuario";
            Volver_desde_usuario.Size = new Size(75, 23);
            Volver_desde_usuario.TabIndex = 55;
            Volver_desde_usuario.Text = "Volver";
            Volver_desde_usuario.UseVisualStyleBackColor = false;
            Volver_desde_usuario.Click += Volver_desde_usuario_Click;
            // 
            // FormUsuarioSimple
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1204, 450);
            ControlBox = false;
            Controls.Add(Volver_desde_usuario);
            Controls.Add(label_set_usuario_actual);
            Controls.Add(label_ver_saldo_credito);
            Controls.Add(label_datos_personales);
            Controls.Add(button_modificar_password);
            Controls.Add(textBox_pass_nuevo);
            Controls.Add(label_modificar_pasword);
            Controls.Add(textBox_pass_viejo);
            Controls.Add(button_Modificar);
            Controls.Add(button_agregar_credito);
            Controls.Add(textBox_email);
            Controls.Add(label_MICredito);
            Controls.Add(textBox_dni);
            Controls.Add(textBox_MiCredito);
            Controls.Add(textBox_apellido);
            Controls.Add(textBox_nombre);
            Controls.Add(textBox_id);
            Controls.Add(label_email);
            Controls.Add(label_dni);
            Controls.Add(label_apellido);
            Controls.Add(label_nombre);
            Controls.Add(label_id);
            Controls.Add(label_vista_usuario);
            Controls.Add(label_bienvenido_client);
            Name = "FormUsuarioSimple";
            Text = "FormUsuarioSimple";
            Load += FormUsuarioSimple_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label_bienvenido_client;
        private Label label_vista_usuario;
        private TextBox textBox_email;
        private TextBox textBox_dni;
        private TextBox textBox_apellido;
        private TextBox textBox_nombre;
        private TextBox textBox_id;
        private Label label_email;
        private Label label_dni;
        private Label label_apellido;
        private Label label_nombre;
        private Label label_id;
        private Button button_Modificar;
        private TextBox textBox_MiCredito;
        private Label label_MICredito;
        private Button button_agregar_credito;
        private Label label_modificar_pasword;
        private TextBox textBox_pass_viejo;
        private TextBox textBox_pass_nuevo;
        private Button button_modificar_password;
        private Label label_datos_personales;
        private Label label_ver_saldo_credito;
        private Label label_set_usuario_actual;
        private Button Volver_desde_usuario;
    }
}